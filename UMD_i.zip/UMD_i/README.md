## UMD-i One-Shot Affordance Transfer Benchmark

UMD-i[1] is a subset of UMD[2] dataset curated for one-shot and
few-shot part segmentation transfer. Each subfolder 
contains the first hand-annotated sample from each
object in UMD. Each sample consists of an rgb image,
binary mask, depth image and affordance numpy array. 

Classes containing each affordance:
Contain - Bowl, Mug, Cup, Pot
Scoop - Spoon, Trowel, Ladle, Scoop
Support - Turner, Shovel
Grasp - Mug, Hammer, Mallet, Knife, Scissors, Spoon, Tenderizer,
        Trowel, Shovel, Turner, Ladle, Scoop, Shears
Wrap-Grasp - Mug, Cup, Pot
Pound - Hammer, Mallet, Tenderizer
Cut - Knife, Scissors, Shears

Following, we provide instructions how to read samples
and run evaluations.

## Reading Samples:

```python
def get_depth_input(path):
  depth_img = cv2.imread(path, cv2.IMREAD_ANYDEPTH)
  depth = depth_img.astype(np.float32) / 1000.0
  return depth

def read_file(path):
  if not os.path.isfile(path):
    raise ValueError("Error: Not path!")
  ext = path.split(".")[-1]
  if ext in ["jpeg","jpg","png"]:
    if not 'depth' in path:
      return cv2.cvtColor(cv2.imread(path), 
                          cv2.COLOR_RGB2BGR)
    else:
      return get_depth_input(path)

  if ext in ["npy"]:
    return np.load(path)
  raise ValueError("Unknown extension %s of path %s"%(ext,path))
  return
```

## Evaluation:

Per-affordance IoU/Fw measures are considered as the standard
benchmark. 

Intra-class evaluation is done as follows:
```
# For each affordance in affordances:
#   affordance_classes = [classes that have this affordance]
#   For each class in affordance_classes:
#     For each object i in class:
#       For each other object j in class:
#         M_ij = Compute metric (IoU or F-measure)
#   Compute mean M for this affordance
# Compute mean M
```

Inter-class evaluation is done as follows:
```
# For each affordance in affordances:
#   affordance_classes = [classes that have this affordance]
#   For each class A in affordance_classes:
#     For each object i in class A:
#       For each class B in affordance_classes:
#         if class A == class B: continue
#         For each other object j in class B:
#           M_ij = Compute metric (IoU or F-measure)
#   Compute mean M for this affordance
# Compute mean M
```

The results from AffCorrs[2]

## References

[1] One-Shot Transfer of Affordance Regions? AffCorrs!, 
Denis Hadjivelichkov, Sicelukwanda Zwane, Marc Deisenroth,
Lourdes Agapito, Dimitrios Kanoulas. 
6th Annual Conference on Robot Learning (CoRL). 2022.
[2] Affordance Detection of Tool Parts from Geometric Features,
Austin Myers, Ching L. Teo, Cornelia Fermüller, Yiannis Aloimonos.
International Conference on Robotics and Automation (ICRA). 2015.


